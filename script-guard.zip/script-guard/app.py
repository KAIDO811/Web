"""
ScriptGuard — a small self-hosted "loadstring protection" service.

What it does:
  - You paste a Lua/Luau script into the admin panel.
  - It gets comment-stripped, minified, and XOR-encoded behind a
    small loadstring decoder stub (see obfuscator.py).
  - You generate a license key for a script. The key locks to
    whoever redeems it first (trust-on-first-use), so your friend
    can use it but can't hand the same key to someone else without
    it breaking for one of them.
  - The Roblox-side snippet just does:
        loadstring(game:HttpGet(url.."?key="..KEY.."&cid="..id))()
    Revoking a key takes effect immediately on the NEXT fetch,
    because nothing is ever cached client-side.

What it deliberately does NOT do: there is no hardware-level lock
(normal Roblox Studio scripts can't see real hardware IDs — that's
an executor-level capability tied to the exploit/cheat ecosystem,
and out of scope here), and there's no attempt to defeat Roblox's
own anti-cheat/anti-exploit systems. This is IP protection between
you and the people you share a key with, nothing more.

Run:
    python3 app.py
Then open http://127.0.0.1:5000 (or whatever host/port you set via
SCRIPTGUARD_HOST / SCRIPTGUARD_PORT env vars).
"""

import os
import secrets
import time
from functools import wraps

from flask import Flask, request, session, redirect, url_for, render_template, abort, Response

import db
from obfuscator import build_roblox_snippet

APP_DIR = os.path.dirname(__file__)
SECRET_KEY_FILE = os.path.join(APP_DIR, ".flask_secret")
ADMIN_PASSWORD_FILE = os.path.join(APP_DIR, ".admin_password")


def _load_or_create_secret() -> bytes:
    if os.path.exists(SECRET_KEY_FILE):
        with open(SECRET_KEY_FILE, "rb") as f:
            return f.read()
    key = secrets.token_bytes(32)
    with open(SECRET_KEY_FILE, "wb") as f:
        f.write(key)
    return key


def _load_or_create_admin_password() -> str:
    env_pw = os.environ.get("SCRIPTGUARD_ADMIN_PASSWORD")
    if env_pw:
        return env_pw
    if os.path.exists(ADMIN_PASSWORD_FILE):
        with open(ADMIN_PASSWORD_FILE) as f:
            return f.read().strip()
    pw = secrets.token_urlsafe(9)
    with open(ADMIN_PASSWORD_FILE, "w") as f:
        f.write(pw)
    print("=" * 60)
    print(f"ScriptGuard admin password (saved to {ADMIN_PASSWORD_FILE}):")
    print(f"    {pw}")
    print("Set SCRIPTGUARD_ADMIN_PASSWORD to override this.")
    print("=" * 60)
    return pw


app = Flask(__name__)
app.secret_key = _load_or_create_secret()
ADMIN_PASSWORD = _load_or_create_admin_password()
BASE_URL = os.environ.get("SCRIPTGUARD_BASE_URL", "http://127.0.0.1:5000")

db.init_db()


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not session.get("admin"):
            return redirect(url_for("login", next=request.path))
        return fn(*a, **kw)
    return wrapper


# ---------------- auth ----------------

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        if secrets.compare_digest(request.form.get("password", ""), ADMIN_PASSWORD):
            session["admin"] = True
            nxt = request.args.get("next") or url_for("admin_home")
            return redirect(nxt)
        error = "كلمة السر غالطة"
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
def index():
    return redirect(url_for("admin_home") if session.get("admin") else url_for("login"))


# ---------------- admin: scripts ----------------

@app.route("/admin")
@login_required
def admin_home():
    scripts = db.list_scripts()
    return render_template("admin_home.html", scripts=scripts, base_url=BASE_URL)


@app.route("/admin/scripts", methods=["POST"])
@login_required
def create_script():
    name = request.form.get("name", "").strip() or "untitled"
    source = request.form.get("source", "")
    if not source.strip():
        return redirect(url_for("admin_home"))
    s = db.create_script(name, source)
    return redirect(url_for("script_detail", script_id=s["id"]))


@app.route("/admin/scripts/<script_id>")
@login_required
def script_detail(script_id):
    s = db.get_script(script_id)
    if not s:
        abort(404)
    keys = db.list_keys(script_id)
    return render_template("script_detail.html", script=s, keys=keys, base_url=BASE_URL, now=time.time())


@app.route("/admin/scripts/<script_id>/update", methods=["POST"])
@login_required
def update_script(script_id):
    s = db.get_script(script_id)
    if not s:
        abort(404)
    new_source = request.form.get("source", "")
    name = request.form.get("name", s["name"]).strip() or s["name"]
    db.update_script_source(script_id, new_source)
    with db._conn() as c:
        c.execute("UPDATE scripts SET name=? WHERE id=?", (name, script_id))
    return redirect(url_for("script_detail", script_id=script_id))


@app.route("/admin/scripts/<script_id>/rotate", methods=["POST"])
@login_required
def rotate_script(script_id):
    db.rotate_obfuscation(script_id)
    return redirect(url_for("script_detail", script_id=script_id))


@app.route("/admin/scripts/<script_id>/delete", methods=["POST"])
@login_required
def delete_script(script_id):
    db.delete_script(script_id)
    return redirect(url_for("admin_home"))


# ---------------- admin: keys ----------------

@app.route("/admin/scripts/<script_id>/keys", methods=["POST"])
@login_required
def create_key(script_id):
    s = db.get_script(script_id)
    if not s:
        abort(404)
    label = request.form.get("label", "").strip()
    days_raw = request.form.get("expires_in_days", "").strip()
    days = int(days_raw) if days_raw.isdigit() else None
    db.generate_key(script_id, label=label, expires_in_days=days)
    return redirect(url_for("script_detail", script_id=script_id))


@app.route("/admin/keys/<int:key_id>/revoke", methods=["POST"])
@login_required
def revoke_key(key_id):
    key = _key_or_404(key_id)
    db.revoke_key(key_id)
    return redirect(url_for("script_detail", script_id=key["script_id"]))


@app.route("/admin/keys/<int:key_id>/unbind", methods=["POST"])
@login_required
def unbind_key(key_id):
    key = _key_or_404(key_id)
    db.unbind_key(key_id)
    return redirect(url_for("script_detail", script_id=key["script_id"]))


@app.route("/admin/keys/<int:key_id>/delete", methods=["POST"])
@login_required
def delete_key(key_id):
    key = _key_or_404(key_id)
    db.delete_key(key_id)
    return redirect(url_for("script_detail", script_id=key["script_id"]))


def _key_or_404(key_id):
    with db._conn() as c:
        row = c.execute("SELECT * FROM license_keys WHERE id=?", (key_id,)).fetchone()
    if not row:
        abort(404)
    return dict(row)


# ---------------- public: the loadstring endpoint ----------------

_ERROR_LUA = "warn(\"ScriptGuard: {msg}\") return"

_FRIENDLY = {
    "not_found": "key not found",
    "wrong_script": "key not valid for this script",
    "revoked": "key revoked",
    "expired": "key expired",
    "bound_mismatch": "key already bound to another device",
}


@app.route("/raw/<script_id>")
def raw_script(script_id):
    s = db.get_script(script_id)
    if not s:
        return Response(_ERROR_LUA.format(msg="unknown script"), mimetype="text/plain")

    key = request.args.get("key", "")
    cid = request.args.get("cid", "") or request.remote_addr or "unknown"

    ok, reason = db.validate_and_consume_key(script_id, key, cid)
    if not ok:
        return Response(_ERROR_LUA.format(msg=_FRIENDLY.get(reason, reason)), mimetype="text/plain")

    return Response(s["obfuscated"], mimetype="text/plain")


@app.route("/admin/scripts/<script_id>/snippet")
@login_required
def snippet(script_id):
    s = db.get_script(script_id)
    if not s:
        abort(404)
    key = request.args.get("key", "YOUR-KEY-HERE")
    return Response(build_roblox_snippet(BASE_URL, script_id, key), mimetype="text/plain")


if __name__ == "__main__":
    host = os.environ.get("SCRIPTGUARD_HOST", "127.0.0.1")
    port = int(os.environ.get("SCRIPTGUARD_PORT", "5000"))
    app.run(host=host, port=port, debug=False)
