"""
obfuscator.py
--------------
Turns a Lua/Luau source string into a "loadstring loader" payload:

    1. Strip comments (safely — never touches the inside of string
       literals or long-bracket strings).
    2. Minify (drop blank lines / trailing whitespace).
    3. Encode the result as raw bytes, XOR it against a random
       per-build key, and emit both as plain Lua number tables.
    4. Wrap everything in a small decoder stub that XORs the bytes
       back, turns them into a string with string.char/table.concat,
       and runs the result with loadstring().

This does NOT change program behaviour — decoding the payload at
runtime always reproduces the original (comment-stripped) script
byte-for-byte. It just means anyone who opens the delivered file sees
numbers instead of readable source.

It is intentionally simple (no fake control-flow, no VM). That keeps
it fast, debuggable, and honest about what it actually does: stop a
casual read/copy-paste, not defeat a dedicated reverse engineer.
"""

import os
import random
import string


class LuaSyntaxWarning(Warning):
    pass


def _strip_comments(src: str) -> str:
    """Remove -- line comments and --[[ ]] / --[=[ ]=] block comments,
    without touching the contents of "..", '..', [[..]] or [=[..]=]
    string literals."""
    out = []
    i = 0
    n = len(src)

    while i < n:
        ch = src[i]

        # Short string literal: "..." or '...'
        if ch == '"' or ch == "'":
            quote = ch
            out.append(ch)
            j = i + 1
            while j < n:
                c = src[j]
                if c == '\\' and j + 1 < n:
                    out.append(c)
                    out.append(src[j + 1])
                    j += 2
                    continue
                out.append(c)
                j += 1
                if c == quote:
                    break
            i = j
            continue

        # Possible long comment: --[[ ]] or --[=[ ]=] , or plain -- line comment
        if src.startswith('--', i):
            k = i + 2
            is_long = False
            close = None
            if k < n and src[k] == '[':
                kk = k + 1
                eq = 0
                while kk < n and src[kk] == '=':
                    eq += 1
                    kk += 1
                if kk < n and src[kk] == '[':
                    is_long = True
                    close = ']' + ('=' * eq) + ']'
                    search_from = kk + 1
            if is_long:
                end = src.find(close, search_from)
                if end == -1:
                    i = n  # unterminated; drop the rest
                else:
                    i = end + len(close)
                continue
            else:
                nl = src.find('\n', i)
                i = n if nl == -1 else nl
                continue

        # Long string literal: [[ ]] or [=[ ]=]
        if ch == '[':
            k = i + 1
            eq = 0
            while k < n and src[k] == '=':
                eq += 1
                k += 1
            if k < n and src[k] == '[':
                close = ']' + ('=' * eq) + ']'
                end = src.find(close, k + 1)
                if end == -1:
                    out.append(src[i:])
                    i = n
                else:
                    out.append(src[i:end + len(close)])
                    i = end + len(close)
                continue

        out.append(ch)
        i += 1

    return ''.join(out)


def _minify(src: str) -> str:
    lines = []
    for line in src.split('\n'):
        stripped = line.rstrip()
        if stripped.strip() == '':
            continue
        lines.append(stripped)
    return '\n'.join(lines)


def _rand_name(rng: random.Random, length: int = 8) -> str:
    chars = string.ascii_letters
    return '_' + ''.join(rng.choice(chars) for _ in range(length))


def _xor_bytes(data: bytes, key: bytes) -> bytes:
    klen = len(key)
    return bytes(b ^ key[i % klen] for i, b in enumerate(data))


def _lua_number_table(data: bytes) -> str:
    return '{' + ','.join(str(b) for b in data) + '}'


def obfuscate_lua_source(source: str, key_size: int = 24, seed: int | None = None) -> str:
    """Return a self-contained Lua stub that, when run, behaves exactly
    like `source` (minus comments/whitespace)."""
    rng = random.Random(seed)

    cleaned = _minify(_strip_comments(source))
    payload_bytes = cleaned.encode('utf-8')

    xor_key = os.urandom(key_size)
    encoded = _xor_bytes(payload_bytes, xor_key)

    data_var = _rand_name(rng)
    key_var = _rand_name(rng)
    decode_fn = _rand_name(rng)
    src_var = _rand_name(rng)
    fn_var = _rand_name(rng)
    err_var = _rand_name(rng)
    i_var = _rand_name(rng, 3)
    t_var = _rand_name(rng, 3)
    kl_var = _rand_name(rng, 3)

    stub = (
        f"local {data_var}={_lua_number_table(encoded)}\n"
        f"local {key_var}={_lua_number_table(xor_key)}\n"
        f"local function {decode_fn}(d,k)\n"
        f"local {t_var}={{}}\n"
        f"local {kl_var}=#k\n"
        f"for {i_var}=1,#d do\n"
        f"{t_var}[{i_var}]=string.char(bit32.bxor(d[{i_var}],k[(({i_var}-1)%{kl_var})+1]))\n"
        f"end\n"
        f"return table.concat({t_var})\n"
        f"end\n"
        f"local {src_var}={decode_fn}({data_var},{key_var})\n"
        f"local {fn_var},{err_var}=loadstring({src_var})\n"
        f"if not {fn_var} then warn('ScriptGuard: '..tostring({err_var})) return end\n"
        f"return {fn_var}()\n"
    )
    return stub


def build_roblox_snippet(base_url: str, script_uid: str, key: str) -> str:
    """The one-liner block the end user pastes into Roblox Studio.
    It fetches /raw/<script_uid>, sends the license key and a best-effort
    client identifier, then loadstrings whatever comes back."""
    return f"""-- ScriptGuard loader — paste this in Roblox Studio
local ScriptGuard_Key = "{key}"
local ScriptGuard_Url = "{base_url}/raw/{script_uid}"

local Players = game:GetService("Players")
local function clientId()
    local ok, id = pcall(function()
        return Players.LocalPlayer and tostring(Players.LocalPlayer.UserId) or tostring(game.JobId)
    end)
    return ok and id or "unknown"
end

local ok, body = pcall(function()
    return game:HttpGet(ScriptGuard_Url .. "?key=" .. ScriptGuard_Key .. "&cid=" .. clientId())
end)

if not ok or not body then
    warn("ScriptGuard: couldn't reach the server")
    return
end

local fn, err = loadstring(body)
if not fn then
    warn("ScriptGuard: " .. tostring(err))
    return
end
fn()
"""
