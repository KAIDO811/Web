"""
db.py — SQLite storage for scripts and license keys.

Design notes on the key/lock system (per the "key + hardware lock"
choice): a real Roblox Studio script (not an external game
executor) has no access to actual hardware identifiers — that kind
of low-level device fingerprinting is specifically an *executor/
exploit* capability, which is out of scope here. What a normal script
CAN see is the local Roblox UserId (when playtesting as a player) or
the server's JobId. So this implements "trust-on-first-use" binding:
a key is free-floating until the first successful redeem, at which
point it locks to whatever client id (cid) redeemed it. Any later
request with a different cid is rejected. Combined with expiry and
one-click revocation (which takes effect immediately since the script
is fetched fresh every time, never cached), this gives you real
control over who can keep using a given key even though it isn't a
hardware lock in the executor-cheat sense.
"""

import os
import secrets
import sqlite3
import string
import threading
import time
import uuid
from contextlib import contextmanager

from obfuscator import obfuscate_lua_source

DB_PATH = os.environ.get("SCRIPTGUARD_DB", os.path.join(os.path.dirname(__file__), "scriptguard.db"))

_lock = threading.Lock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS scripts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    source TEXT NOT NULL,
    obfuscated TEXT NOT NULL,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS license_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT UNIQUE NOT NULL,
    script_id TEXT NOT NULL,
    label TEXT,
    bound_cid TEXT,
    created_at REAL NOT NULL,
    expires_at REAL,
    revoked INTEGER NOT NULL DEFAULT 0,
    last_used_at REAL,
    use_count INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (script_id) REFERENCES scripts(id)
);
"""


@contextmanager
def _conn():
    with _lock:
        c = sqlite3.connect(DB_PATH)
        c.row_factory = sqlite3.Row
        try:
            yield c
            c.commit()
        finally:
            c.close()


def init_db():
    with _conn() as c:
        c.executescript(_SCHEMA)


# ---------- scripts ----------

def create_script(name: str, source: str) -> dict:
    sid = uuid.uuid4().hex[:12]
    obf = obfuscate_lua_source(source)
    now = time.time()
    with _conn() as c:
        c.execute(
            "INSERT INTO scripts (id, name, source, obfuscated, created_at, updated_at) VALUES (?,?,?,?,?,?)",
            (sid, name, source, obf, now, now),
        )
    return get_script(sid)


def list_scripts() -> list:
    with _conn() as c:
        rows = c.execute("SELECT id, name, created_at, updated_at FROM scripts ORDER BY updated_at DESC").fetchall()
        return [dict(r) for r in rows]


def get_script(script_id: str) -> dict | None:
    with _conn() as c:
        row = c.execute("SELECT * FROM scripts WHERE id=?", (script_id,)).fetchone()
        return dict(row) if row else None


def update_script_source(script_id: str, new_source: str) -> dict | None:
    obf = obfuscate_lua_source(new_source)
    now = time.time()
    with _conn() as c:
        c.execute(
            "UPDATE scripts SET source=?, obfuscated=?, updated_at=? WHERE id=?",
            (new_source, obf, now, script_id),
        )
    return get_script(script_id)


def rotate_obfuscation(script_id: str) -> dict | None:
    """Re-encode with a fresh random XOR key without changing the source.
    Useful if you suspect a cached copy leaked and want all *future*
    fetches to look different (old cached copies still work logically,
    they just don't help anyone guess the new encoding)."""
    script = get_script(script_id)
    if not script:
        return None
    return update_script_source(script_id, script["source"])


def delete_script(script_id: str):
    with _conn() as c:
        c.execute("DELETE FROM license_keys WHERE script_id=?", (script_id,))
        c.execute("DELETE FROM scripts WHERE id=?", (script_id,))


# ---------- keys ----------

_KEY_ALPHABET = string.ascii_uppercase.translate(str.maketrans('', '', 'IO')) + string.digits.translate(str.maketrans('', '', '01'))


def _format_key() -> str:
    groups = []
    for _ in range(4):
        groups.append(''.join(secrets.choice(_KEY_ALPHABET) for _ in range(4)))
    return '-'.join(groups)


def generate_key(script_id: str, label: str = "", expires_in_days: int | None = None) -> dict:
    key = _format_key()
    now = time.time()
    expires_at = now + expires_in_days * 86400 if expires_in_days else None
    with _conn() as c:
        c.execute(
            "INSERT INTO license_keys (key, script_id, label, created_at, expires_at) VALUES (?,?,?,?,?)",
            (key, script_id, label, now, expires_at),
        )
    return get_key(key)


def get_key(key: str) -> dict | None:
    with _conn() as c:
        row = c.execute("SELECT * FROM license_keys WHERE key=?", (key,)).fetchone()
        return dict(row) if row else None


def list_keys(script_id: str) -> list:
    with _conn() as c:
        rows = c.execute(
            "SELECT * FROM license_keys WHERE script_id=? ORDER BY created_at DESC", (script_id,)
        ).fetchall()
        return [dict(r) for r in rows]


def revoke_key(key_id: int):
    with _conn() as c:
        c.execute("UPDATE license_keys SET revoked=1 WHERE id=?", (key_id,))


def unbind_key(key_id: int):
    """Clear the bound client id, e.g. if your friend reinstalled / switched accounts."""
    with _conn() as c:
        c.execute("UPDATE license_keys SET bound_cid=NULL WHERE id=?", (key_id,))


def delete_key(key_id: int):
    with _conn() as c:
        c.execute("DELETE FROM license_keys WHERE id=?", (key_id,))


def validate_and_consume_key(script_id: str, key: str, cid: str) -> tuple[bool, str]:
    """Returns (ok, reason). reason is one of:
    ok, not_found, wrong_script, revoked, expired, bound_mismatch
    On first successful use, binds the key to `cid`."""
    row = get_key(key)
    if not row:
        return False, "not_found"
    if row["script_id"] != script_id:
        return False, "wrong_script"
    if row["revoked"]:
        return False, "revoked"
    if row["expires_at"] and time.time() > row["expires_at"]:
        return False, "expired"

    now = time.time()
    if not row["bound_cid"]:
        with _conn() as c:
            c.execute(
                "UPDATE license_keys SET bound_cid=?, last_used_at=?, use_count=use_count+1 WHERE id=?",
                (cid, now, row["id"]),
            )
        return True, "ok"

    if row["bound_cid"] != cid:
        return False, "bound_mismatch"

    with _conn() as c:
        c.execute(
            "UPDATE license_keys SET last_used_at=?, use_count=use_count+1 WHERE id=?",
            (now, row["id"]),
        )
    return True, "ok"
